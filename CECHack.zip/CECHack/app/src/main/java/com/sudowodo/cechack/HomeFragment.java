package com.sudowodo.cechack;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by Belal on 1/23/2018.
 */

public class HomeFragment extends Fragment {


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //just change the fragment_dashboard

        View rootView = inflater.inflate(R.layout.fragment_home, null);
        RecyclerView recyclerView = (RecyclerView) rootView.findViewById(R.id.);

        return rootView;
    }
}